import { unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-a2935813.js";
import { Head } from "@inertiajs/vue3";
import "./ApplicationLogo-45e4c2fc.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    tasks: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Tasks" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}>Tasks</h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, "Tasks")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"${_scopeId}><div class="flex flex-col"${_scopeId}><div class="overflow-x-auto sm:-mx-6 lg:-mx-8"${_scopeId}><div class="inline-block min-w-full py-2 sm:px-6 lg:px-8"${_scopeId}><div class="overflow-hidden"${_scopeId}><table class="text-left text-sm font-light"${_scopeId}><thead class="border-b font-medium dark:border-neutral-500"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-4"${_scopeId}>#</th><th scope="col" class="px-6 py-4"${_scopeId}>Title</th><th scope="col" class="px-6 py-4"${_scopeId}>Status</th><th scope="col" class="px-6 py-4"${_scopeId}>Description</th><th scope="col" class="px-6 py-4"${_scopeId}>Deadline</th><th scope="col" class="px-6 py-4"${_scopeId}>Assign To</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.tasks, (task, key) => {
              _push2(`<tr class="border-b dark:border-neutral-500"${_scopeId}><td class="whitespace-nowrap px-6 py-4 font-medium"${_scopeId}>${ssrInterpolate(++key)}</td><td class="whitespace-nowrap px-6 py-4"${_scopeId}>${ssrInterpolate(task.title)}</td>`);
              if (task.status == 1) {
                _push2(`<td class="whitespace-nowrap px-6 py-4"${_scopeId}>Open</td>`);
              } else {
                _push2(`<!---->`);
              }
              if (task.status == 2) {
                _push2(`<td class="whitespace-nowrap px-6 py-4"${_scopeId}>In-progress</td>`);
              } else {
                _push2(`<!---->`);
              }
              if (task.status == 3) {
                _push2(`<td class="whitespace-nowrap px-6 py-4"${_scopeId}>Done</td>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<td class="whitespace-nowrap px-6 py-4"${_scopeId}>${ssrInterpolate(task.description)}</td><td class="whitespace-nowrap px-6 py-4"${_scopeId}>${ssrInterpolate(task.deadline)}</td><td class="whitespace-nowrap px-6 py-4"${_scopeId}>${ssrInterpolate(task.user_info.name)}</td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white overflow-hidden shadow-sm sm:rounded-lg" }, [
                    createVNode("div", { class: "flex flex-col" }, [
                      createVNode("div", { class: "overflow-x-auto sm:-mx-6 lg:-mx-8" }, [
                        createVNode("div", { class: "inline-block min-w-full py-2 sm:px-6 lg:px-8" }, [
                          createVNode("div", { class: "overflow-hidden" }, [
                            createVNode("table", { class: "text-left text-sm font-light" }, [
                              createVNode("thead", { class: "border-b font-medium dark:border-neutral-500" }, [
                                createVNode("tr", null, [
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-4"
                                  }, "#"),
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-4"
                                  }, "Title"),
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-4"
                                  }, "Status"),
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-4"
                                  }, "Description"),
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-4"
                                  }, "Deadline"),
                                  createVNode("th", {
                                    scope: "col",
                                    class: "px-6 py-4"
                                  }, "Assign To")
                                ])
                              ]),
                              createVNode("tbody", null, [
                                (openBlock(true), createBlock(Fragment, null, renderList(__props.tasks, (task, key) => {
                                  return openBlock(), createBlock("tr", { class: "border-b dark:border-neutral-500" }, [
                                    createVNode("td", { class: "whitespace-nowrap px-6 py-4 font-medium" }, toDisplayString(++key), 1),
                                    createVNode("td", { class: "whitespace-nowrap px-6 py-4" }, toDisplayString(task.title), 1),
                                    task.status == 1 ? (openBlock(), createBlock("td", {
                                      key: 0,
                                      class: "whitespace-nowrap px-6 py-4"
                                    }, "Open")) : createCommentVNode("", true),
                                    task.status == 2 ? (openBlock(), createBlock("td", {
                                      key: 1,
                                      class: "whitespace-nowrap px-6 py-4"
                                    }, "In-progress")) : createCommentVNode("", true),
                                    task.status == 3 ? (openBlock(), createBlock("td", {
                                      key: 2,
                                      class: "whitespace-nowrap px-6 py-4"
                                    }, "Done")) : createCommentVNode("", true),
                                    createVNode("td", { class: "whitespace-nowrap px-6 py-4" }, toDisplayString(task.description), 1),
                                    createVNode("td", { class: "whitespace-nowrap px-6 py-4" }, toDisplayString(task.deadline), 1),
                                    createVNode("td", { class: "whitespace-nowrap px-6 py-4" }, toDisplayString(task.user_info.name), 1)
                                  ]);
                                }), 256))
                              ])
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Task/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
