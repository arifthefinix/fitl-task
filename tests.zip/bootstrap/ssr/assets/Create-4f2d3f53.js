import { unref, withCtx, createVNode, createTextVNode, withModifiers, withDirectives, vModelText, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelSelect, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-a2935813.js";
import { useForm, Head } from "@inertiajs/vue3";
import "./Checkbox-cfea886a.js";
import { _ as _sfc_main$2, a as _sfc_main$3, b as _sfc_main$4 } from "./TextInput-0364e26d.js";
import { P as PrimaryButton } from "./PrimaryButton-d82933f3.js";
import "./ApplicationLogo-45e4c2fc.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Create",
  __ssrInlineRender: true,
  props: {
    users: Object
  },
  setup(__props) {
    const form = useForm({
      title: "",
      description: "",
      deadline: "",
      assign_to: ""
    });
    const submit = () => {
      form.post(route("tasks.store"), {
        onFinish: () => form.reset("title", "description", "deadline", "assign_to")
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Create New Task" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 leading-tight"${_scopeId}>Create New Task</h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 leading-tight" }, "Create New Task")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg"${_scopeId}><form${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "title",
              value: "Title"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "title",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(form).title,
              "onUpdate:modelValue": ($event) => unref(form).title = $event,
              required: "",
              autofocus: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.title
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "description",
              value: "Description"
            }, null, _parent2, _scopeId));
            _push2(`<textarea id="description" type="textarea" class="mt-1 block w-full" required${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.description
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "deadline",
              value: "Deadline"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "deadline",
              type: "date",
              class: "mt-1 block w-full",
              modelValue: unref(form).deadline,
              "onUpdate:modelValue": ($event) => unref(form).deadline = $event,
              required: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.deadline
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "assign_to",
              value: "Assign To"
            }, null, _parent2, _scopeId));
            _push2(`<select id="assign_to" type="select" class="mt-1 block w-full"${_scopeId}><!--[-->`);
            ssrRenderList(__props.users, (user) => {
              _push2(`<option${ssrRenderAttr("value", user.id)}${_scopeId}>${ssrInterpolate(user.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.assign_to
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center justify-end mt-4"${_scopeId}>`);
            _push2(ssrRenderComponent(PrimaryButton, {
              class: ["ml-4", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Create Task `);
                } else {
                  return [
                    createTextVNode(" Create Task ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form></div>`);
          } else {
            return [
              createVNode("div", { class: "w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg" }, [
                createVNode("form", {
                  onSubmit: withModifiers(submit, ["prevent"])
                }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "title",
                      value: "Title"
                    }),
                    createVNode(_sfc_main$3, {
                      id: "title",
                      type: "text",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).title,
                      "onUpdate:modelValue": ($event) => unref(form).title = $event,
                      required: "",
                      autofocus: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.title
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", { class: "mt-4" }, [
                    createVNode(_sfc_main$2, {
                      for: "description",
                      value: "Description"
                    }),
                    withDirectives(createVNode("textarea", {
                      id: "description",
                      type: "textarea",
                      class: "mt-1 block w-full",
                      "onUpdate:modelValue": ($event) => unref(form).description = $event,
                      required: ""
                    }, null, 8, ["onUpdate:modelValue"]), [
                      [vModelText, unref(form).description]
                    ]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.description
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", { class: "mt-4" }, [
                    createVNode(_sfc_main$2, {
                      for: "deadline",
                      value: "Deadline"
                    }),
                    createVNode(_sfc_main$3, {
                      id: "deadline",
                      type: "date",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).deadline,
                      "onUpdate:modelValue": ($event) => unref(form).deadline = $event,
                      required: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.deadline
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", { class: "mt-4" }, [
                    createVNode(_sfc_main$2, {
                      for: "assign_to",
                      value: "Assign To"
                    }),
                    withDirectives(createVNode("select", {
                      id: "assign_to",
                      "onUpdate:modelValue": ($event) => unref(form).assign_to = $event,
                      type: "select",
                      class: "mt-1 block w-full"
                    }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(__props.users, (user) => {
                        return openBlock(), createBlock("option", {
                          value: user.id
                        }, toDisplayString(user.name), 9, ["value"]);
                      }), 256))
                    ], 8, ["onUpdate:modelValue"]), [
                      [vModelSelect, unref(form).assign_to]
                    ]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.assign_to
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", { class: "flex items-center justify-end mt-4" }, [
                    createVNode(PrimaryButton, {
                      class: ["ml-4", { "opacity-25": unref(form).processing }],
                      disabled: unref(form).processing
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Create Task ")
                      ]),
                      _: 1
                    }, 8, ["class", "disabled"])
                  ])
                ], 40, ["onSubmit"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Task/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
